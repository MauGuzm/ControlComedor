
<nav class="navbar navbar-inverse navbar-static-top">
      <div class="container">
          <a class="navbar-brand" href="../index.php">Casa Sommer</a>
					<ul>
  <li><a href="admin_portada.php">Usuarios</a></li>
  <li><a href="Menu.php">Menu</a></li>
  <li><a href="contact.php">RespuestasForms</a></li>
  <li style="float:right"><a href="../cerrar_sesion.php"><button class="btn-danger" aria-hidden="true"></span> Cerrar Sesion</button></a></li>
          </ul>
        </div>
      </div>
    </nav>