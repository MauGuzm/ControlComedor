<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
<title>Sommer</title>
<link rel="shortcut icon" href="img/favicon.png">
<link rel="stylesheet" href="css/Login.css">
 <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
	<body>
	<div class="header">
	<!-- <img src="img/logo.png" alt=""> -->
  <center> <p>SISTEMA COMEDOR</p></center>
  <div class="header-right">

  </div>
</div>
<style>
	 body{
 background-image:url('img/fondo2.jpg');
 /* background-color:white; */
background-size: cover;
background-attachment: fixed;
background-repeat: no-repeat;
height: 100%;
width: 100%;
min-height: 100%;
position: relative;
}
.header {
      overflow: hidden;
	  background-color:black;
      padding: 40px 10px;
      height: 120px;
	  background-color: #3b3b3b;
    }
    
    .header p {
      color: white;
      font-size: 18px; 
       line-height: 25px; 
       border-radius: 4px; 
    color: white;
   font-style: large;
   text-transform: uppercase;
  letter-spacing: 0.5em;
  display: inline-block;
 
  border-width: 4px 0;
  padding: 1.5em 0em;
  position: center;
 top: 2%;


    }
</style>
<?php
require_once 'DBconnect.php';
session_start();
if(isset($_SESSION["admin_login"]))	//Condicion admin
{
	header("location: admin/Dashboard.php");
}
// if(isset($_SESSION["personal_login"]))	//Condicion personal
// {
// 	header("location: personal/admin_portada.php");
// }
if(isset($_SESSION["usuarios_login"]))	//Condicion Usuarios
{
	header("location: usuarios/usuarios_portada.php");
}

if(isset($_REQUEST['btn_login']))
{
	$email		=$_REQUEST["txt_email"];	//textbox nombre "txt_email"
	$password	=$_REQUEST["txt_password"];	//textbox nombre "txt_password"
	$role		=$_REQUEST["txt_role"];		//select opcion nombre "txt_role"

	if(empty($email)){
		$errorMsg[]="Por favor ingrese Email";	//Revisar email
	}
	else if(empty($password)){
		$errorMsg[]="Por favor ingrese Password";	//Revisar password vacio
	}
	else if(empty($role)){
		$errorMsg[]="Por favor seleccione rol ";	//Revisar rol vacio
	}
	else if($email AND $password AND $role)
	{
		try
		{
			$select_stmt=$db->prepare("SELECT email,password,role FROM userlogin 
			WHERE email=:uemail AND password=:upassword AND role=:urole");
			
			$select_stmt->bindParam(":uemail",$email);
			$select_stmt->bindParam(":upassword",$password);
			$select_stmt->bindParam(":urole",$role);
			$select_stmt->execute();	//execute query

			while($row=$select_stmt->fetch(PDO::FETCH_ASSOC))
			{
				$dbemail	=$row["email"];
				$dbpassword	=$row["password"];
				$dbrole		=$row["role"];
			}
			if($email!=null AND $password!=null AND $role!=null)
			{
				if($select_stmt->rowCount()>0)
				{
					if($email==$dbemail and $password==$dbpassword and $role==$dbrole)
					{
						switch($dbrole)		//inicio de sesión de usuario base de roles
						{
							case "admin":
								$_SESSION["admin_login"]=$email;
								$loginMsg="Admin: Inicio sesión con éxito";
								header("refresh:3;admin/Dashboard.php");
								break;

						

							case "usuarios":
								$_SESSION["usuarios_login"]=$email;
								$loginMsg="Usuario: Inicio sesión con éxito";
								header("refresh:3;usuarios/usuarios_portada.php");
								break;

							default:
								$errorMsg[]="correo electrónico o contraseña o rol incorrectos";
						}
					}
					else
					{
						$errorMsg[]="correo electrónico o contraseña o rol incorrectos";
					}
				}
				else
				{
					$errorMsg[]="correo electrónico o contraseña o rol incorrectos";
				}
			}
			else
			{
				$errorMsg[]="correo electrónico o contraseña o rol incorrectos";
			}
		}
		catch(PDOException $e)
		{
			$e->getMessage();
		}
	}
	else
	{
		$errorMsg[]="correo electrónico o contraseña o rol incorrectos";
	}
}

?>


	<div class="wrapper">

	<div class="container">

		<div class="col-lg-12">

		<?php
		if(isset($errorMsg))
		{
			foreach($errorMsg as $error)
			{
			?>
				<div class="alert alert-danger">
					<strong><?php echo $error; ?></strong>
				</div>
            <?php
			}
		}
		if(isset($loginMsg))
		{
		?>
			<div class="alert alert-success">
				<strong>ÉXITO ! <?php echo $loginMsg; ?></strong>
			</div>
        <?php
		}
		?>


<br>

<div class="login-form">

<form method="post" class="form-horizontal">
<center><h2>Bienvenido</h2></center>
  <div class="form-group">
  <label class="col-sm-6 text-left">Email</label>
  <div class="col-sm-12">
  <input type="text" name="txt_email" class="form-control" placeholder="Ingrese email" />
  </div>
  </div>

  <div class="form-group">
  <label class="col-sm-6 text-left">Contraseña</label>
  <div class="col-sm-12">
  <input type="password" name="txt_password" class="form-control" placeholder="Ingrese contraseña" />
  </div>
  </div>

  <div class="form-group">
      <label class="col-sm-6 text-left">Seleccionar rol</label>
      <div class="col-sm-12">
      <select class="form-control" name="txt_role">
          <option value="" selected="selected"> - selecccionar rol - </option>
          <option value="admin">Admin</option>
          <!-- <option value="personal">Personal</option> -->
          <option value="usuarios">Usuario</option>
      </select>
      </div>
  </div>

   <div class="form-group">
  <div class="col-sm-12">
	<p></p>
	<!-- <a href="index.html" class="btn btn-primary btn-user btn-block">
                                            Login
                                        </a> -->
  <input type="submit" name="btn_login" class="btn btn-primary btn-user btn-block"" value="Iniciar Sesion">
  </div>
  </div>
</form>
</div>
<!--Cierra div login-->
		

  <p></p>

<!-- <b>Derechos de autor © 2022 Lammsa - Todos los derechos reservados.</b> -->
		</div>
  </div>
  
	</body>
</html>