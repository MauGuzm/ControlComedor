  <?php 
  function timer()
  {
    $data =
     [
  'title' => 'Timer o cuenta regresiva'
    ];

    View::render('timer',$data);
  } 
