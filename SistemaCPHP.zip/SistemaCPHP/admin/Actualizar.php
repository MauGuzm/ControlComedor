
<!--  -->
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Actualizar</title>
<link rel="shortcut icon" href="../img/favicon.png">
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">


<style>
  body{
    background-color:white;
  }
  p{
    font-family: sans-serif;
  }
</style>
<?php
require('../DBconnect.php');

$id = $_GET['EDITAR_ID'];
$select_stmt= "SELECT * FROM userlogin WHERE id = :id"; 
$stmt = $db->prepare($select_stmt);
$stmt->bindParam(':id', $id, PDO::PARAM_INT); 
$stmt->execute();
$obj = $stmt->fetchObject();
				
?>
<script language="javascript" type="text/javascript">
function windowClose() {
window.open('','_parent','');
window.close();
}
</script>  
</head>
  

<?php
// $status = "";
if(isset($_POST["enviar"]))
{
   
    $username=trim($_POST['username']);
    $email=trim($_POST['email']);
    $password=trim($_POST['password']);
    $role=trim($_POST['role']);
    $cve=trim($_POST['cve']);
    $departamento=trim($_POST['departamento']);
    $id=trim($_POST['id']);


    $update = "UPDATE userlogin
    SET `username`= :username, `email` = :email,`password`= :password, `role` = :role,`cve` = :cve , `departamento` = :departamento 
    WHERE `id` = :id";
    
    $select_stmt = $db->prepare($update);
    $select_stmt->bindParam(':username',$username,PDO::PARAM_STR, 25);
    $select_stmt->bindParam(':email',$email,PDO::PARAM_STR, 25);
    $select_stmt->bindParam(':password',$password,PDO::PARAM_STR,25);
    $select_stmt->bindParam(':role',$role,PDO::PARAM_STR,25);
    $select_stmt->bindParam(':departamento',$departamento,PDO::PARAM_STR);
    $select_stmt->bindParam(':cve',$cve,PDO::PARAM_STR);
    $select_stmt->bindParam(':id',$id,PDO::PARAM_INT);

    $select_stmt->execute();
    if($select_stmt->rowCount() > 0)
    {
    $count = $select_stmt -> rowCount();
    echo "<div class='content alert alert-primary' > 
    
      
    Gracias: $count registro ha sido actualizado  </div>";
    header("Location: admin_portada.php");
    }
    else{
        echo "<div class='content alert alert-danger'> No se pudo actulizar el registro  </div>";
    
    print_r($select_stmt->errorInfo()); 
    }
 
}

else {
   
?> 
  
  
<body id="main_body" >
	
	<!-- <img id="top" src="top.png" alt=""> -->
	<div id="form_container">
	<h1> <center><p>Editar</p></h1>
	<form id="form_18653" class="appnitro"  method="post" action="">
	<div class="form_description">
	</div>						
    <ul >

   <center>
   <div class="col-12 col-md-12"> 

<form role="form" method="POST" action="<?php $_SERVER['PHP_SELF']  ?>">
    <input value="<?php echo $obj->id;?>" name="id" type="hidden">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="username">Username</label>
      <input value="<?php echo $obj->username;?>" name="username" type="text" class="form-control" placeholder="username">
    </div>

    <div class="form-group col-md-6">
      <label bgolor="#F0F3F4"  for="edad">Email</label>
      <input value="<?php echo $obj->email;?>" name="email" type="text" class="form-control" id="edad" placeholder="email">
    </div>
  </div>

  <div class="form-row">  
    <div class="form-group col-md-6">
      <label for="password">password</label>
      <input value="<?php echo $obj->password;?>" name="password" type="text" class="form-control" id="password" placeholder="password">
    </div>

    <div class="form-group col-md-6">
    <label for="role">Role</label>
    <select required name="role" class="form-control" id="role">
    <option value="<?php echo $obj->role;?>"><?php echo $obj->role;?></option>        
    <option value=""><< >></option>
    <option value="admin">Administrador</option>
    <option value="usuarios">Usuario</option>
    </select>
</div>
<div class="form-group col-md-6">
  <label for="cve">Departamento</label>
  <input value="<?php echo $obj->cve?>" name="cve" type="text" class="form-control" placeholder="cve">

</div>

<div class="form-group col-md-6">
  <label for="departamento">Departamento</label>
  <input value="<?php echo $obj->departamento?>" name="departamento" type="text" class="form-control" placeholder="departamento">

</div>
</div>
<div class="form-group">
  <button name="enviar" type="submit" class="btn btn-primary  btn-block">Actualizar Registro</button>
  <a href="../admin_portada.php"><input   class="btn btn-danger btn-block" value="Cancelar" ></a>
</div>
</form>
    </div> 
		
    <?php } ?>
      
	</div>
	</body>
</html>