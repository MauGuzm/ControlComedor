<?php include_once "../funciones.php";?>
<?php 
require_once("../DBconnect.php");  

$select_stmt=$db->prepare("SELECT  * FROM productos p INNER JOIN carrito_usuarios c
ON p.id = c.id_producto ");
$select_stmt->execute();
while ($row = $select_stmt->fetch(PDO::FETCH_ASSOC)) {
//    echo $row['nombre']."".$row['descripcion']."<br>".$row['id_producto']." <br><br>";
echo $row['nombre']."". 
 $row['descripcion']."<br>".
$row['id_producto']."<br><br>";
}
?>