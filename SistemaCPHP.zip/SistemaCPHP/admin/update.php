<?php

// Incluir el fichero para realizar la conexion
include('../DBconect.php');
// La consulta SQL que nos mostrara los registros en la tabla
$query = "SELECT * FROM user ORDER BY id DESC";

$select_stmt = $bd->prepare($query);

if($statement->execute())
{
// Ciclo PDO que sera en encargado de mostrar los registros de la BD
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }

 echo json_encode($data);
}

?>
