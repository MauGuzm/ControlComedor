
<!--  -->
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>ActualizaMenu</title>
<link rel="shortcut icon" href="../img/favicon.png">
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<link rel="shortcut icon" href="img/favicon.png">

<style>
  body{
    background-image:url('top.png');
    background-attachment: fixed;
    background-size: cover; 
  }
  p{
    font-family: sans-serif;
  }
</style>
<?php
require('../DBconnect.php');

$id = $_GET['EDITAR_ID'];
$select_stmt= "SELECT * FROM menu WHERE ID = :ID"; 
$stmt = $db->prepare($select_stmt);
$stmt->bindParam(':ID', $id, PDO::PARAM_INT); 
$stmt->execute();
$obj = $stmt->fetchObject();
				
?>
<script language="javascript" type="text/javascript">
function windowClose() {
window.open('','_parent','');
window.close();
}
</script>  
</head>
  

<?php
// $status = "";
if(isset($_POST["enviar"]))
{
   
    $Tipo=trim($_POST['Tipo']);
    $Nombre=trim($_POST['Nombre']);
    $Descripcion=trim($_POST['Descripcion']);
    $dias=trim($_POST['dias']);
    $fecha=trim($_POST['fecha']);



    $update = "UPDATE menu
    SET `Tipo`= :Tipo, `Nombre` = :Nombre,`Descripcion`= :Descripcion, `dias` = :dias,`fecha` = :fecha  
    WHERE `ID` = :ID";
    
    $select_stmt = $db->prepare($update);
    $select_stmt->bindParam(':Tipo',$Tipo,PDO::PARAM_STR, 25);
    $select_stmt->bindParam(':Nombre',$Nombre,PDO::PARAM_STR, 25);
    $select_stmt->bindParam(':Descripcion',$Descripcion,PDO::PARAM_STR,25);
    $select_stmt->bindParam(':dias',$dias,PDO::PARAM_STR,25);
    $select_stmt->bindParam(':fecha',$fecha,PDO::PARAM_STR);
    $select_stmt->bindParam(':ID',$id,PDO::PARAM_STR);

  

    $select_stmt->execute();
    if($select_stmt->rowCount() > 0)
    {
    $count = $select_stmt -> rowCount();
    echo "<div class='content alert alert-primary' > 
    
      
    Gracias: $count registro ha sido actualizado  </div>";
    header("Location: Menu.php");
    }
    else{
        echo "<div class='content alert alert-danger'> No se pudo actulizar el registro  </div>";
    
    print_r($select_stmt->errorInfo()); 
    }
 
}

else {
   
?> 
  
  
<body id="main_body" >
	
	<img id="top" src="" alt="">
	<div id="form_container">
	<h1> <center><p>Editar</p></h1>
	<form id="form_18653" class="appnitro"  method="post" action="">
	<div class="form_description">
	</div>						
    <ul >

   <center>
   <div class="col-12 col-md-12"> 

<form role="form" method="POST" action="<?php $_SERVER['PHP_SELF']  ?>">
    <input value="<?php echo $obj->id;?>" name="ID" type="hidden">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="username">Tipo</label>
      <input value="<?php echo $obj->Tipo;?>" name="Tipo" type="text" class="form-control" placeholder="Tipo">
    </div>

    <div class="form-group col-md-6">
      <label bgolor="#F0F3F4"  for="edad">Nombre</label>
      <input value="<?php echo $obj->Nombre;?>" name="Nombre" type="text" class="form-control" id="edad" placeholder="Nombre">
    </div>
  </div>

  <div class="form-row">  
    <div class="form-group col-md-6">
      <label for="Descripcion">Descripcion</label>
      <input value="<?php echo $obj->Descripcion;?>" name="Descripcion" type="text" class="form-control" id="Descripcion" placeholder="Descripcion">
    </div>

    <div class="form-group col-md-6">
    <label for="dias">Días</label>
    <select required name="dias" class="form-control" id="dias">
    <option value="<?php echo $obj->dias;?>"><?php echo $obj->dias;?></option>        
    <option value=""><< >></option>
    <option value="Lunes">Lunes</option>
    <option value="Martes">Martes</option>
    <option value="Miercoles">Miercoles</option>
    <option value="Jueves">Jueves</option>
    <option value="Viernes">Viernes</option>
    </select>
</div>
<div class="form-group col-md-6">
  <label for="fecha">Fecha</label>
  <input value="<?php echo $obj->fecha?>" name="fecha" type="text" class="form-control" placeholder="fecha">

</div>

</div>
<div class="form-group">
  <button name="enviar" type="submit" class="btn btn-primary  ">Actualizar </button>
  <a href="../admin_portada.php"><input   class="btn btn-danger " value="Cancelar" ></a>
</div>
</form>
    </div> 
		
    <?php } ?>
      
	</div>
	</body>
</html>