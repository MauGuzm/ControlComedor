<?php
require_once("../DBconnect.php");
$result;
$db=new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_password);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$_GET["id"];

if(isset($_GET["id"]))
{
    $select_stmt=$db->prepare("DELETE  FROM userlogin WHERE id = ". $_GET["id"]);
	$select_stmt->execute();
    header("Location: admin_portada2.php");
}
else{
    echo("");
}
?>

