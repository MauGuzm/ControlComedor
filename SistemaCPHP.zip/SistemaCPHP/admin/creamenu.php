<?php 
    include('../DBconnect.php');
  if(isset($_POST['insertar'])){
    ///////////// Informacion enviada por el formulario /////////////
    $Tipo=$_POST['Tipo'];
    $Nombre=$_POST['Nombre'];
    $Descripcion=$_POST['Descripcion'];
    $dias=$_POST['dias'];
    $fecha = date('Y-m-d');
    // $archivo = $_POST['archivo']['name'];
    ///////// Fin informacion enviada por el formulario /// 
    
    ////////////// Insertar a la tabla la informacion generada /////////
    $sql="INSERT INTO menu(Tipo,Nombre,Descripcion,dias,fecha) values(:Tipo,:Nombre,:Descripcion,:dias,:fecha)";
        
    $sql = $db->prepare($sql);
    $sql->bindParam(':Tipo',$Tipo,PDO::PARAM_STR, 25);   
    $sql->bindParam(':Nombre',$Nombre,PDO::PARAM_STR, 25);
    $sql->bindParam(':Descripcion',$Descripcion,PDO::PARAM_STR,25);
    $sql->bindParam(':dias',$dias,PDO::PARAM_STR,25);
    $sql->bindParam(':fecha',$fecha,PDO::PARAM_STR);
    // $sql->bindParam('archivo0',$archivo,PDO::PARAM_STR);
        
    $sql->execute();
    
    $lastInsertID = $db->lastInsertID();
    if($lastInsertID>0){
    
    echo "<div class='content alert alert-primary' > Gracias Has Ingreasado un Platillo    </div>";
    }
    else{
        echo "<div class='content alert alert-danger'> No se pueden agregar datos, comuníquese con el administrador  </div>";
    
    print_r($sql->errorInfo()); 
    }
    }
    // Cierra envio de guardado <button  class='glyphicon glyphicon-remove'>
?>
<a href="Menu.php"><button  class="btn btn-primary">  REGRESAR</button></a>