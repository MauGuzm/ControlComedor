
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Menu</title>
    <!-- Custom styles for this template-->
<link href="css/sb-admin-2.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/bulma@0.9.1/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css"> 
</head>
<?php include_once "funciones.php";
$productos = obtenerProductosEnCarrito();
if (count($productos) <= 0) {
?>
<body id="page-top">
    <section class="hero is-info">
        <div class="hero-body">
            <div class="container">
                <h1 class="title">
                    Tu menu esta vacio
                </h1>
                <h2 class="subtitle">
                    Visita el menu para agregar productos a tabla
                </h2>
                <a href="tienda.php" class="button is-warning">Ver Menu</a>
            </div>
        </div>
    </section>
<?php 
} else { ?>
    <div class="columns">
        <div class="column">
            <h2 class="is-size-2">Mi Menu agregado</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <!-- <th>Días</th> -->
                        <th>Quitar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    foreach ($productos as $producto) {
                        // $total ;
                    ?>
                        <tr>
                            <td><?php echo $producto->nombre ?></td>
                            <td><?php echo $producto->descripcion ?></td>
                            <!-- <td><?php echo $producto->dias ?></td> -->
                            <td>
                                <form action="eliminar_del_carrito.php" method="post">
                                    <input type="hidden" name="id_producto" value="<?php echo $producto->id ?>">
                                    <input type="hidden" name="redireccionar_carrito">
                                    <button class="button is-danger">Borrar
                                        <i class="fa fa-trash-o"></i>
                                    </button>
                                </form>
                            </td>
                        <?php } ?>
                        </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <!-- <td colspan="2" class="is-size-4 has-text-right"><strong>Total</strong></td> -->
                        <td colspan="2" class="is-size-4">
                            <!-- $<?php echo number_format($total, 2) ?> -->
                        </td>
                    </tr>
                </tfoot>
            </table>
            <center>
            <a href="usuarios/usuarios_portada.php" class="button is-success is-large"><i class="fa "></i>&nbsp;Regresar</a>
        </div>
    </div>
<?php } ?>
</body>
</html>
