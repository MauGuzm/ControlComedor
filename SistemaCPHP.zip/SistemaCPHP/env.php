; <?php exit; ?>
MYSQL_DATABASE_NAME = "bd_comedor"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""