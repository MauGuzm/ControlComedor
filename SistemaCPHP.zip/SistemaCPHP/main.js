
//Timer
$('#fecha').on('change', run_timer);
function run_timer(){
var fecha = $('#fecha').val(),
limite = new Date(fecha).getTime(),
wraper = $('.wraper_timer'),
ahora = new Date().getTime(),
restante = limite - ahora,
dias = Math.floor(restante/(1000*60*60*24)),
horas = Math.floor((restante %(1000*60*60*24))/(1000*60*60)),
minutos = Math.floor((restante %(1000*60*60))/(1000*60)),
segundos = Math.floor((restante % (1000*60))/1000),
texto = '';

// Si el tiempo expiro
if (restante<0) {
    wraper.html('div class="alert alert-danger text-center">El tiempo ha expirado.</div>');
}
if(dias>0){
    texto+=dias + 'dias,';
}
if(horas>0){
    texto+=horas + 'horas,';
}
if(minutos>0){
    texto+=minutos + 'minutos,';
}
if(segundos>0){
    texto+=segundos + 'segundos,';
}
//Mostrar texto
wraper.html(run_timer,1000);

setTimeout(run_timer,1000);
}

function run_loader() {
    
}

function destroy_loader(){

}

run_loader();

