<?php
require_once("../DBconnect.php");
$result;
$db=new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_password);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$_GET["ID"];

if(isset($_GET["ID"]))
{
    $select_stmt=$db->prepare("DELETE  FROM menu WHERE ID = ". $_GET["ID"]);
	$select_stmt->execute();
    header("Location: usuarios_portada.php");
}
else{
    echo("");
}
?>

