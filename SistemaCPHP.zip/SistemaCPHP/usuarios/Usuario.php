<?php include("../DBconnect.php");?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
<title>Usuarios</title>
<link rel="stylesheet" media="all" href="style.css">
<link rel="stylesheet" href="table.css">
<link rel="stylesheet" href="slidebar.css">		
<link rel="stylesheet" href="table-boostrap.css">
<link rel="shortcut icon" href="../img/favicon.png">
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> -->
 
<style type="text/css">
  
	.login-form {
		width: 340px;
    	margin: 20px auto;
	}
    .login-form form {
    	margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .btn {        
        height: 48px;
        font-size: 15px;
        font-weight: bold;
    }
 .dias{
  background-color:black;
 }
</style>
</head>
	<body>
		                 <!-- Sidebar -->
                         <ul> 
  <li><a href="usuarios_portada.php">Inicio</a></li>
  <li><a href="">Perfil</a></li>
  <li><a href="#contact"></a></li>
  <a style="float:right"  href="../cerrar_sesion.php"><button class="btn btn-danger text-left"><span class="glyphicon  aria-hidden="true"></span> Cerrar Sesion</button></a>
  <li style="float:right"><a class="active" href="formsqs.php">Quejas y Sugerencias</a></li>
  </ul>			
  <style>
    body{
     background-color:gray;
    }
  </style>
  <center>
				<h3>
				<?php
				
				session_start();
				if(!isset($_SESSION['usuarios_login']))	
				{
					header("location: ../index.php");
				}
				if(isset($_SESSION['admin_login']))	
				{
					header("location: ../admin/admin_portada.php");
				}
			if(isset($_SESSION['usuarios_login']))
				{
				?>
					Bienvenidos,
				<?php
						echo $_SESSION['usuarios_login'];
				}
				?>
      </center> 
      <center><h1>MENÚ</h1>
      
              




<hr> 
<?php 
if(isset($_POST['insertar'])){
///////////// Informacion enviada por el formulario /////////////

$ID_menu=$_POST['ID_menu'];
$Nombre=$_POST['Nombre'];
$Imagen= $_FILES['Imagen'];
$Descripcion =$_POST('Descripcion');
$ID =$_POST('ID');

$sql="INSERT INTO platillos(ID_menu,Nombre,Imagen,Descripcion) values(:ID_menu,Nombre,:Imagen,:Descripcion)";
    
$sql = $db->prepare($sql);
    
$sql->bindParam(':ID_menu',$ID_menu,PDO::PARAM_STR, 25);
$sql->bindParam(':Nombre',$Nombre,PDO::PARAM_STR, 25);
$sql->bindParam(':Imagen',$Imagen,PDO::PARAM_STR,25);
$sql->bindParam(':Descripcion',$Descripcion,PDO::PARAM_STR);
$sql->bindParam(':ID',$ID,PDO::PARAM_STR);
    
$sql->execute();

}

?>
 <center>
    <p1>Ingresa las opciones</p1>

        <!--Tabla de Usuarios -->       
        <!-- <div class="table-responsive">  </div>       
<table class="table  table-bordered ">
  <thead class="thead-dark">
    <tr>
      <th >Menu</th>
      <th >Lunes</th>
      <th >Martes</th>
      <th >Miercoles</th>
      <th>Jueves</th>
      <th>Viernes</th>
      <th>Icono</th>
    </tr> -->
 
    <?php 
    		require_once '../DBconnect.php';
          
            $select_stmt=$db->prepare("SELECT ID,nombre_menu,dias,Platillo,fecha FROM menu");
            $select_stmt->execute();
            // $_GET['ID'];
            while($row=$select_stmt->fetch(PDO::FETCH_ASSOC))
            {
     ?>
<tr>
    <!-- <div  dias="">Selecciona el día:
    <select name="dias" id="dias">
  <option value="l">Lunes</option>
  <option value="ma">Martes</option>
  <option value="mi">Miercoles</option>
  <option value="j">Jueves</option>
  <option value="v">Viernes</option>
</select>

   </div> -->

    <div>
     <?php echo $row["nombre_menu"]; ?>   </div> 

       <div>                              <?php echo $row["dias"]; ?></div>   
       <div>   <?php echo $row["Platillo"]; ?>  </div>   
       <div>                      <?php echo $row["fecha"]; ?>    </div>   
                                                                      
                                            <a href="view.php?ID=<?php echo $row['ID']; ?>" type="submit" class="btn btn-default">Ver</a>
                                                <a href="Delete.php?ID=<?php echo $row['ID']; ?>" <?php echo $row['ID']; ?> type="submit" class="btn btn-danger">Eliminar</a>
                                                <a href="" type="submit" class="btn btn-primary">Editar</a>
                                                <a href="" type="submit" class="btn btn-success">Enviar</a>
                                                
                                                <!-- <td width="250">
                                            
                                            </td> -->
                                            <!-- <?php echo $row['ID']; ?> -->
                                            <!-- </tr>  -->
     <?php 
  }
     ?>
  </thead>
 
</table>	
					
	</body>
</html>