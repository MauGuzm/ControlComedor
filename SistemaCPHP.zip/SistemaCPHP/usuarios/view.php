

<!DOCTYPE html>
<html>
    <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link href='http://fonts.googleapis.com/css?family=Holtwood+One+SC' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="../css/styles.css">

    </head>
    <style>
        body{
            background-color:gray;
        }
        .container {
          background-color:orange;
        }
    </style>
    <?php
 require_once '../DBconnect.php';

 if(!empty($_GET['ID'])) 
 { 
  $id = $_GET['ID'];
 $select_stmt=$db->prepare("SELECT ID,Platillo,Descripcion,dias,fecha FROM menu WHERE ID = ?");
 $select_stmt->execute(array($id));  
 $row = $select_stmt->fetch(PDO::FETCH_ASSOC)


?>
    <?php 


    if(isset($_POST['Ordenar'])){
        ///////////// Informacion enviada por el formulario /////////////
        $id = $_POST['id'];
        $Platillo = $_POST['Platillo'];
        $Descripcion=$_POST['Descripcion'];
        $HORARIO = TIME('H:i:s');

        $sql="INSERT INTO mimenu(id,Platillo,Descripcion,HORARIO) values(:id,:Platillo,:Descripcion,:HORARIO)";
    
$sql = $db->prepare($sql);
$sql->bindParam(':id',$id,PDO::PARAM_STR, 25);   
$sql->bindParam(':Platillo',$Platillo,PDO::PARAM_STR, 25);
$sql->bindParam(':Descripcion',$Descripcion,PDO::PARAM_STR,25);
$sql->bindParam(':HORARIO',$HORARIO,PDO::PARAM_STR);
    
$sql->execute();
}

?>
    <body>
        <h1 class="text-logo"><span class="glyphicon glyphicon-cutlery"></span> Menú <span class="glyphicon glyphicon-cutlery"></span></h1>
         <div class="container admin">
            <div class="row">
               <div class="col-sm-6">
                    <h1><strong>Ver producto</strong></h1>
                    <br>
                    
                    <form>
                      <div class="form-group">
                      
                        <label>ID:</label><?php echo $row['ID'];?>
                      </div>
                      <div class="form-group">
                        <label>Descripción:</label><?php echo $row['Platillo'];?>
                      </div>
                      <div class="form-group">
                        <label>Día:</label><?php echo $row['dias'];?>
                      </div>
                      <div class="form-group">
                        <label>Fecha:</label><?php echo $row['fecha'];?>
                      </div>
                    </form>
         
                    <br>
                    <div class="form-actions">
                      <a class="btn btn-primary" href="usuarios_portada.php"><span class="glyphicon glyphicon-arrow-left"></span> Regresar</a>
                    </div>
                </div> 
       
                <div class="col-sm-6 site">
                    <div class="thumbnail">
                         <!-- <img src="<?php echo '../imgs/'.$row['image'];?>" alt="...">  -->
                        <img src="../imgs/image.png" alt="">
                     
                          <div class="caption">
                            <h4><?php echo $row['Platillo'];?></h4>
                            <p><?php echo $row['Descripcion'];?></p>

                            <!-- <a href="mimenu.php " class="btn btn-order" role="button"><span class="glyphicon glyphicon-shopping-cart"></span> Ordenar</a> -->
                          </div> 
                    </div>
                </div>
            </div>
            
        </div> 
        <?php  
           }
            
          ?>
    </body>
</html>

